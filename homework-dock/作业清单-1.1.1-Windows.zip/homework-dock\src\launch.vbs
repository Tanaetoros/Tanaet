Option Explicit

Dim fso, shell, here, ps, args, i, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

here = fso.GetParentFolderName(WScript.ScriptFullName)
ps = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"

args = ""
For i = 0 To WScript.Arguments.Count - 1
    args = args & " """ & Replace(WScript.Arguments(i), """", """""") & """"
Next

cmd = """" & ps & """" & " -STA -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & here & "\run.ps1""" & args
shell.Run cmd, 0, False
